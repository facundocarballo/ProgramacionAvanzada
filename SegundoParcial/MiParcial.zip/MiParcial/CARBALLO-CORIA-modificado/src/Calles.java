
public class Calles {
	protected Grafo grafo;
	protected int desde;
	protected int hasta;
	
	public Calles(Grafo graf, int desd, int hast){
		grafo = graf;
		desde = desd;
		hasta = hast;
	}
	
}
