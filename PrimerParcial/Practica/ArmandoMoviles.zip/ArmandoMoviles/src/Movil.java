
public class Movil {
	
	// Atributos
	protected int pesoColgante;
	
	// Constructor
	public Movil(int c1) {
		this.pesoColgante = c1;
	}
	
	// Metodos
	public int peso_del_movil() {
		return this.pesoColgante*2;
	}
	
}
