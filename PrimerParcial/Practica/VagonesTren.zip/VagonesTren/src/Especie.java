
public class Especie {
	
	// Atributos
	protected String nombre;
	protected int agresividad, cantidad;
	
	// Constructor
	public Especie(String nombre, int agresividad, int cant) {
		this.agresividad = agresividad;
		this.nombre = nombre;
		this.cantidad = cant;
	}
	
	// Metodo
	
}
